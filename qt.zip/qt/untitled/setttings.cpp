#include "setttings.h"
#include "ui_setttings.h"

Setttings::Setttings(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Setttings)
{
    ui->setupUi(this);
}

Setttings::~Setttings()
{
    delete ui;
}
