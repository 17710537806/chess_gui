#include "menu.h"
#include "ui_menu.h"

Menu::Menu(QWidget *parent) : QWidget(parent), ui(new Ui::Menu) {
    ui->setupUi(this);

    //设置窗口图标
    setWindowIcon(QIcon(":/icon.png"));

    //设置窗口标题
    setWindowTitle("菜单");

    board = std::vector<std::vector<int>> (6, std::vector<int>(6));
    ui->line->setMaximum(0);

    //链接信号
    connect(ui->btn_exit, &QPushButton::clicked, this, &Menu::close);
    connect(ui->btn_read, &QPushButton::clicked, this, &Menu::Read);

    //关联滚动条和棋盘联系
    QObject::connect(ui->line, &QScrollBar::valueChanged, [this](int value){
        //改变当前位置并更新棋盘
        if(!List.empty()) {
            board = List[value];
            QString bc = "X ";
            QString rd = "X ";

            std::vector<int> res = check(board);

            bc.append(QString::number(12 - res[1]));
            rd.append(QString::number(12 - res[0]));

            ui->black_label->setText(bc);
            ui->red_label->setText(rd);
        }
        update();
    });

    ui->red_label->setStyleSheet("color: red; font-size: 24px; font-weight: bold;");
    ui->black_label->setStyleSheet("color: red; font-size: 24px; font-weight: bold;");

    select = 1;
}

void Menu::Read() {
    qDebug() << "读入棋谱";
    QString filePath = QFileDialog::getOpenFileName(nullptr, "选择文件", "", "文本文件 (*.txt)");

    // 用户取消了文件选择
    if (filePath.isEmpty()) {
        return;
    }

    QFile file(filePath);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(nullptr, "错误", "无法打开文件: " + file.errorString());
        return;
    }

    QTextStream in(&file);

    int size;
    std::vector<std::vector<int>> res = std::vector<std::vector<int>> (6, std::vector<int>(6));

    in >> size;

    if(size < 1) {
        QMessageBox::critical(nullptr, "错误", "文件异常");
        return;
    }

    init();

    for(int i = 0; i < size; ++i) {
        int cnt_1 = 0, cnt_2 = 0;
        for(int j = 0; j < 6; ++j) {
            for(int k = 0; k < 6; ++k) {
                in >> res[j][k];
                if(res[j][k] == 0) {
                    ++cnt_1;
                } else if(res[j][k] == 1) {
                    ++cnt_2;
                }
            }
        }
        if(cnt_1 > 12 || cnt_2 > 12) {
            QMessageBox::critical(nullptr, "错误", "文件异常");
            return;
        }
        List.push_back(res);
    }

    board = List[0];
    ui->line->setMaximum(List.size() - 1);
    ui->line->setValue(0);
    file.close();

    QString bc = "X ";
    QString rd = "X ";

    std::vector<int> mid = check(board);

    bc.append(QString::number(12 - mid[1]));
    rd.append(QString::number(12 - mid[0]));

    ui->black_label->setText(bc);
    ui->red_label->setText(rd);

    update();
}

void Menu::init() {
    //初始位置置0，棋盘棋谱清空
    ui->line->setMaximum(0);
    ui->line->setValue(0);

    if(!List.empty()) {
        List.clear();
    }
    for(int i = 0; i < 6; ++i) {
        for(int j = 0; j < 6; ++j) {
            board[i][j] = -1;
        }
    }

    select = 1;

    ui->black_label->setText("X 12");
    ui->red_label->setText("X 12");
}

void Menu::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);

    //获取窗口长和宽
    int width = 600, height = 400;
    //qDebug() << "width:" << width << "heigh:" << height;

    //求棋盘可以获取最大的大小，并进行留白
    int max_size = fmin(width, height);
    int margin = max_size / 11;

    //设置画笔
    QPainter painter(this);

    //设置画笔颜色
    QPen YellowPen(QColor(255, 242, 0));
    QPen BluePen(QColor(0, 162, 232));
    QPen GreenPen(QColor(22, 116, 50));
    QPen WhitePen(Qt::white);
    QBrush BlackPen(Qt::black);
    QBrush RedPen(Qt::red);
    QBrush Pen(QColor(82, 191, 255));

    //设置画笔粗度
    YellowPen.setWidth(4);
    BluePen.setWidth(4);
    GreenPen.setWidth(4);

    //画黄色棋盘线
    painter.setPen(YellowPen);
    painter.drawLine(3 * margin, 3 * margin, 8 * margin, 3 * margin);
    painter.drawLine(3 * margin, 3 * margin, 3 * margin, 8 * margin);
    painter.drawLine(8 * margin, 3 * margin, 8 * margin, 8 * margin);
    painter.drawLine(3 * margin, 8 * margin, 8 * margin, 8 * margin);

    //画蓝色棋盘线
    painter.setPen(BluePen);
    painter.drawLine(4 * margin, 3 * margin, 4 * margin, 8 * margin);
    painter.drawLine(7 * margin, 3 * margin, 7 * margin, 8 * margin);
    painter.drawLine(3 * margin, 4 * margin, 8 * margin, 4 * margin);
    painter.drawLine(3 * margin, 7 * margin, 8 * margin, 7 * margin);

    //画蓝色吃子线
    QRectF left_top(2 * margin, 2 * margin, 2 * margin, 2 * margin);
    painter.drawArc(left_top, 0, 270 * 16);
    QRectF right_top(7 * margin, 2 * margin, 2 * margin, 2 * margin);
    painter.drawArc(right_top, 270 * 16, 270 * 16);
    QRectF left_bottom(2 * margin, 7 * margin, 2 * margin, 2 * margin);
    painter.drawArc(left_bottom, 90 * 16, 270 * 16);
    QRectF right_bottom(7 * margin, 7 * margin, 2 * margin, 2 * margin);
    painter.drawArc(right_bottom, 180 * 16, 270 * 16);

    //画绿色棋盘线
    painter.setPen(GreenPen);
    painter.drawLine(5 * margin, 3 * margin, 5 * margin, 8 * margin);
    painter.drawLine(6 * margin, 3 * margin, 6 * margin, 8 * margin);
    painter.drawLine(3 * margin, 5 * margin, 8 * margin, 5 * margin);
    painter.drawLine(3 * margin, 6 * margin, 8 * margin, 6 * margin);

    //画绿色吃子线
    QRectF Left_top(1 * margin, 1 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Left_top, 0, 270 * 16);
    QRectF Right_top(6 * margin, 1 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Right_top, 270 * 16, 270 * 16);
    QRectF Left_bottom(1 * margin, 6 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Left_bottom, 90 * 16, 270 * 16);
    QRectF Right_bottom(6 * margin, 6 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Right_bottom, 180 * 16, 270 * 16);
    int R = 0.75 * margin;
    painter.setPen(WhitePen);

    //画棋子
    for(int i = 0; i < 6; ++i) {
        for(int j = 0; j < 6; ++j) {
            if(board[i][j] == 0) {
                painter.setBrush(BlackPen);
                painter.drawEllipse((j + 3) * margin - 1.0 / 3 * margin, (i + 3) * margin - 1.0 / 3 * margin, R, R);
            } else if(board[i][j] == 1) {
                painter.setBrush(RedPen);
                painter.drawEllipse((j + 3) * margin - 1.0 / 3 * margin, (i + 3) * margin - 1.0 / 3 * margin, R, R);
            }
        }
    }

    //画标记
    painter.setBrush(BlackPen);
    painter.drawEllipse(530, 50, 1.2 * R, 1.2 * R);
    painter.setBrush(RedPen);
    painter.drawEllipse(400, 50, 1.2 * R, 1.2 * R);
}

std::vector<int> Menu::check(std::vector<std::vector<int>>& bd) {
    int cnt_1 = 0, cnt_2 = 0;
    for(int i = 0; i < 6; ++i) {
        for(int j = 0; j < 6; ++j) {
            if(bd[i][j] == 0) {
                ++cnt_1;
            } else if(bd[i][j] == 1) {
                ++cnt_2;
            }
        }
    }
    return {cnt_1, cnt_2};
}

void Menu::mousePressEvent(QMouseEvent *event) {
    //调用基类的鼠标事件处理函数
    QWidget::mousePressEvent(event);

    int mouseX = event->position().x();
    int mouseY = event->position().y();

    int width = 600, height = 400;
    int max_size = fmin(width, height);
    int margin = max_size / 11;
    int R = 0.75 * margin;


    for (int i = 0; i < 6; ++i) {
        for (int j = 0; j < 6; ++j) {
            int circleX = (j + 3) * margin - 1.0 / 3 * margin;
            int circleY = (i + 3) * margin - 1.0 / 3 * margin;

            // 判断点击是否在棋盘的圆内
            if ((mouseX >= circleX && mouseX <= circleX + R) && (mouseY >= circleY && mouseY <= circleY + R)) {
                // 点击了第 i 行，第 j 列的圆
                qDebug() << "Clicked circle at (" << i << ", " << j << ")";
                std::vector<int> mid = check(board);

                QString bc = "X ";
                QString rd = "X ";

                bool flag = false;
                //如果选中的是红色
                if(select == 0 && mid[0] < 12 && board[i][j] != 0) {
                    board[i][j] = 0;
                    std::vector<int> res = check(board);
                    bc.append(QString::number(12 - res[1]));
                    rd.append(QString::number(12 - res[0]));
                    ui->black_label->setText(bc);
                    ui->red_label->setText(rd);
                    flag = true;
                } else if(select == 1 && mid[1] < 12 && board[i][j] != 1) {//否则是黑色
                    board[i][j] = 1;
                    std::vector<int> res = check(board);
                    bc.append(QString::number(12 - res[1]));
                    rd.append(QString::number(12 - res[0]));
                    ui->black_label->setText(bc);
                    ui->red_label->setText(rd);
                    flag = true;
                }

                if(!flag) {
                    QString Bc = "X ";
                    QString Rd = "X ";

                    if(select == 0 && board[i][j] == 0) {
                        board[i][j] = -1;
                        Bc.append(QString::number(12 - mid[1]));
                        Rd.append(QString::number(12 - mid[0] + 1));
                        ui->black_label->setText(Bc);
                        ui->red_label->setText(Rd);
                    }

                    if(select == 1 && board[i][j] == 1) {
                        board[i][j] = -1;
                        Bc.append(QString::number(12 - mid[1] + 1));
                        Rd.append(QString::number(12 - mid[0]));
                        ui->black_label->setText(Bc);
                        ui->red_label->setText(Rd);
                    }
                }
            }
        }
    }

    if((mouseX >= 530 && mouseX <= 530 + 1.2 * R) && (mouseY >= 50 && mouseY <= 50 + 1.2 * R)) {
        qDebug() << "选中了黑棋";
        select = 0;
    }

    if((mouseX >= 400 && mouseX <= 400 + 1.2 * R) && (mouseY >= 50 && mouseY <= 50 + 1.2 * R)) {
        qDebug() << "选中了红棋";
        select = 1;
    }

    update();
}

Menu::~Menu()
{
    delete ui;
}
