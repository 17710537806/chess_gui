#ifndef END_WIDGET_H
#define END_WIDGET_H

#include <QWidget>
#include <QPainter>
#include <vector>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>

namespace Ui {
class End_widget;
}

class End_widget : public QWidget {
    Q_OBJECT

private slots:
    //记时信号
    void save();

public:
    explicit End_widget(QWidget *parent = nullptr);
    ~End_widget();

    //设置棋谱
    void set_List(std::vector<std::vector<std::vector<int>>> list);

    //获取获胜者
    void get_winner(int id, int op);

    //获取每步时间
    void set_time(std::vector<int> vt);

private:
    //画棋盘函数
    void paintEvent(QPaintEvent *event) override;

    std::vector<int> Vector_Time;

    //当前棋谱步数
    int now_step;

    //输的原因
    int loss;

    //谁输了
    int ID;

    //记录比赛的顺序表
    std::vector<std::vector<std::vector<int>>> List;

    Ui::End_widget *ui;
};

#endif // END_WIDGET_H
