#ifndef MENU_H
#define MENU_H

#include <QWidget>
#include <QPainter>
#include <vector>
#include <QFileDialog>
#include <QMessageBox>
#include <vector>
#include <QMouseEvent>

#include "setttings.h"

namespace Ui {
class Menu;
}

class Menu : public QWidget {
    Q_OBJECT

private slots:
    //记时信号
    void Read();

public:
    explicit Menu(QWidget *parent = nullptr);
    ~Menu();

    void init();

private:
    //画棋盘函数
    void paintEvent(QPaintEvent *event) override;

    //棋盘
    std::vector<std::vector<int>> board;

    //棋谱
    std::vector<std::vector<std::vector<int>>> List;

    //鼠标点击事件
    void mousePressEvent(QMouseEvent *event) override;

    //数子函数
    std::vector<int> check(std::vector<std::vector<int>>& bd);

    Ui::Menu *ui;

    //判断选中了什么色的棋子
    int select;
};

#endif // MENU_H
