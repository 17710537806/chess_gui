#include "game_board.h"
#include <cmath>
#include <cstdlib>

Game_board::Game_board() {
    //初始化棋盘大小
    board = std::vector<std::vector<int>> (6, std::vector<int>(6));

    //初始化
    init();

}

void Game_board::init() {
    //初始棋子位置
    for(int i = 0; i < 6; ++i) {
        for(int j = 0; j < 6; ++j) {
            if(i <= 1) {
                board[i][j] = 0;
            } else if(i >= 4) {
                board[i][j] = 1;
            } else {
                board[i][j] = -1;
            }
        }
    }

    //清空之前比赛状态
    List.clear();
    //初始化棋盘上棋子数量为12
    cnt1 = cnt2 = 12;
    //初始化最开始走子的玩家为玩家2
    now_player = 1;

    //记录棋盘状态
    List.push_back(board);
}

void Game_board::change_player() {
    now_player ^= 1;
}

void Game_board::Retract() {
    //如果为开始则不做处理
    if(List.size() == 1) {
        return;
    }

    now_player ^= 1;
    List.pop_back();
    board = List.back();
}

bool Game_board::is_in_board(int x, int y) {
    return x >= 0 && x < 6 && y >= 0 && y < 6;
}

bool Game_board::is_legal(int x1, int y1, int x2, int y2) {
    //如果初始位置和目标位置不在棋盘上，或者移动的不是自己棋子，亦或者没移动则操作非法
    if(!is_in_board(x1, y1) || !is_in_board(y1, y2) || board[x1][y1] != now_player || (x1 == x2 && y1 == y2)) {
        return false;
    }
    //如果是吃子
    if(board[x2][y2] == (now_player ^ 1)) {
        //如果不在四个边上，肯定吃子非法
        if(!(x1 == 0 || x1 == 5 || y1 == 0 || y1 == 5)) {
            return false;//如果在四个角上，那么也非法
        } else if ((x1 == y1 || x1 + y1 == 5) && (x1 == 0 || x1 == 5)) {
            return false;
        } else {
            //判断四个象限
            //如果是二四象限
            if((x1 <= 2 && y1 <= 2) || (x1 >= 3 && y1 >= 3)) {
                return x1 == y2 && y1 == x2;
            } else {//如果是一三象限
                return x1 + y2 == 5 && x2 + y1 == 5;
            }
        }
    } else {//否则是正常走子
        //如果目标点不为空则非法
        if(board[x2][y2] != -1) {
            return false;
        } else {//否则走子水平和竖直移动距离君不大于1
            return std::abs(x1 - x2) <= 1 && std::abs(y1 - y2) <= 1;
        }
    }
}

void Game_board::move(int x1, int y1, int x2, int y2) {
    //判断是否有吃子情况发生
    if(board[x2][y2] == 0) {
        --cnt1;
    } else if(board[x2][y2] == 1) {
        --cnt2;
    }
    //移动子并将移动前的位置清空
    board[x2][y2] = board[x1][y1];
    board[x1][y1] = -1;
}

int Game_board::play(int x1, int y1, int x2, int y2) {
    //如果非法则返回错误
    if(!is_legal(x1, y1, x2, y2)) {
        return -1;
    }

    //执行玩家操作
    move(x1, y1, x2, y2);
    //交换回合
    now_player ^= 1;
    //将当前棋盘状态存入顺序表
    List.push_back(board);

    qDebug() << "红方还剩:" << cnt2 << "黑方还剩:" << cnt1;
    //判断是否有玩家棋子被吃光
    if(!cnt1) return 2;
    if(!cnt2) return 1;
    return 0;
}

std::vector<std::vector<int>> Game_board::get_board() {
    return board;
}

int Game_board::get_nowPlayer() {
    return this->now_player;
}

std::vector<std::vector<std::vector<int>>> Game_board::get_List() {
    return List;
}
