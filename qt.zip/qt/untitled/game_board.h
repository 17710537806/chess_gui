#ifndef GAME_BOARD_H
#define GAME_BOARD_H

#include <vector>
#include <QDebug>

class Game_board {
private:
    //棋盘
    std::vector<std::vector<int>> board;

    //记录比赛的顺序表
    std::vector<std::vector<std::vector<int>>> List;

    //记录双方子数和当前玩家
    int cnt1 = 0;
    int cnt2 = 0;
    int now_player = 1;

public:
    Game_board();

    //初始化棋盘
    void init();

    //判断玩家操作是否合法
    bool is_legal(int x1, int y1, int x2, int y2);

    //判断是否在棋盘内
    bool is_in_board(int x, int y);

    //判断玩家操作并执行
    int play(int x1, int y1, int x2, int y2);

    //获取棋盘
    std::vector<std::vector<int>> get_board();

    //执行玩家操作
    void move(int x1, int y1, int x2, int y2);

    //获取当前玩家
    int get_nowPlayer();

    //更改玩家先后手
    void change_player();

    //悔棋
    void Retract();

    //获取棋谱
    std::vector<std::vector<std::vector<int>>> get_List();
};

#endif // GAME_BOARD_H
