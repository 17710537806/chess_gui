#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QResizeEvent>
#include <QTimer>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QAction>
#include <QMouseEvent>
#include <vector>

#include "end_widget.h"
#include "game_board.h"
#include "qdatetime.h"
#include "menu.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

private slots:
    //记时信号
    void Countdown();

    //开始按钮被点击信号
    void onBtnBeginClicked();

    //停止按钮被点击信号
    void onBtnStopClicked();

    //切换按钮被点击信号
    void onBtnChangeClicked();

    //切换按钮被点击信号
    void onBtnRetractClicked();

    //认输按钮被点击信号
    void onBtnDefeatClicked();

    //菜单按钮被点击信号
    void onBtnMenuClicked();
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    //重写窗体大小改变信号
    void resizeEvent(QResizeEvent *event) override;

private:
    Ui::MainWindow *ui;

    //画棋盘函数
    void paintEvent(QPaintEvent *event) override;

    //鼠标点击事件
    void mousePressEvent(QMouseEvent *event) override;

    //初始化函数
    void init();

    //棋盘指针
    Game_board* board;

    //计时器标签
    QLabel* TimerLabel;

    //计时器对象
    QTimer* Timer;

    QTime targetTime;

    //结算窗口
    End_widget* ew;

    //菜单窗口
    Menu* mu;

    //控件修改函数
    void btn_position();

    //自定义步数时间
    int time = 30;

    //剩余时间
    int remainingSeconds;

    //是否选中
    bool is_select;

    //选中坐标
    int select_x;
    int select_y;

    //判断是否在进行比赛
    bool is_in_game;

    //判断是否是开始
    bool is_first;

    //是否切换了先手
    bool change;

    //判断是否需要刷新计时器
    bool refresh;

    //判断是否比赛结束
    bool is_end;

    //判断之前是否切换过先后手
    bool is_changed;

    //记录比赛时间
    std::vector<int> TimeVector;

};
#endif // MAINWINDOW_H
