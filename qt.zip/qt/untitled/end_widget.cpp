#include "end_widget.h"
#include "ui_end_widget.h"

End_widget::End_widget(QWidget *parent) : QWidget(parent), ui(new Ui::End_widget) {
    ui->setupUi(this);

    //设置窗口图标
    setWindowIcon(QIcon(":/icon.png"));

    //设置窗口标题
    setWindowTitle("复盘界面");

    //初始位置为0
    now_step = 0;

    //关联滚动条和棋盘联系
    QObject::connect(ui->get_now_step, &QScrollBar::valueChanged, [this](int value){
        //改变当前位置并更新棋盘
        now_step = value;

        //如果到输的位置
        QString Timer;
        if(value >= (int)Vector_Time.size() - 1) {
            if(loss == 0) {
                if(ID == 1) {
                    Timer = "黑方认输";
                } else {
                    Timer = "红方认输";
                }
            } else if(loss == 1) {
                if(ID == 1) {
                    Timer = "黑方超时";
                } else {
                    Timer = "红方超时";
                }
            } else {

            }
        } else {
            Timer = QString("此步同时：%1:%2:%3")
                                .arg(Vector_Time[value + 1] / 3600, 2, 10, QLatin1Char('0'))
                                .arg((Vector_Time[value + 1] / 60) % 60, 2, 10, QLatin1Char('0'))
                                .arg(Vector_Time[value + 1] % 60, 2, 10, QLatin1Char('0'));
        }
        ui->time->setText(Timer);
        update();
    });

    //关联函数与信号
    connect(ui->btn_exit, &QPushButton::clicked, this, &End_widget::close);
    connect(ui->btn_save, &QPushButton::clicked, this, &End_widget::save);

    //设置字体大小
    ui->winner->setStyleSheet("color: red; font-size: 24px; font-weight: bold;");
    ui->time->setStyleSheet("color: red; font-size: 16px; font-weight: bold;");
}

void End_widget::save() {
    QString save_path = QFileDialog::getSaveFileName(nullptr, "保存", "Chess manual.txt", "QFileDevice::Text files (.txt)");
    if (!save_path.isEmpty()) {
        QFile file(save_path);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            QTextStream stream(&file);
            stream << List.size() << '\n';
            for(int i = 0; i < (int)List.size(); ++i) {
                for(int j = 0; j < 6; ++j) {
                    for(int k = 0; k < 6; ++k) {
                        stream << List[i][j][k] << " ";
                    }
                    stream << "\n";
                }
            }
            file.close();
        }
        QMessageBox::information(nullptr, "保存成功", "文件保存成功！");
    }
}

void End_widget::get_winner(int id, int op) {
    loss = op;
    ID = id;
    if(id == 1) {
        qDebug() << "红方获胜";
        ui->winner->setText("获胜方：红方");
    } else {
        qDebug() << "黑方获胜";
        ui->winner->setText("获胜方：黑方");
    }
}

void End_widget::set_List(std::vector<std::vector<std::vector<int>>> list) {
    List = list;
    ui->get_now_step->setMaximum(list.size() - 1);
    ui->get_now_step->setValue(0);
}

void End_widget::set_time(std::vector<int> vt) {
    Vector_Time = vt;
    QString Timer = QString("此步同时：%1:%2:%3")
                        .arg(Vector_Time[1] / 3600, 2, 10, QLatin1Char('0'))
                        .arg((Vector_Time[1] / 60) % 60, 2, 10, QLatin1Char('0'))
                        .arg(Vector_Time[1] % 60, 2, 10, QLatin1Char('0'));
    ui->time->setText(Timer);
    if(List.size() == 1) {
        if(ID == 1) {
            if(loss == 0) {
                ui->time->setText("黑方认输");
            } else if(loss == 1) {
                ui->time->setText("黑方超时");
            }
        } else {
            if(loss == 0) {
                ui->time->setText("红方认输");
            } else if(loss == 1) {
                ui->time->setText("红方超时");
            }
        }
    }
    update();
}

void End_widget::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);

    //获取窗口长和宽
    int width = 600, height = 400;
    //qDebug() << "width:" << width << "heigh:" << height;

    //求棋盘可以获取最大的大小，并进行留白
    int max_size = fmin(width, height);
    int margin = max_size / 11;

    //设置画笔
    QPainter painter(this);

    //设置画笔颜色
    QPen YellowPen(QColor(255, 242, 0));
    QPen BluePen(QColor(0, 162, 232));
    QPen GreenPen(QColor(22, 116, 50));
    QPen WhitePen(Qt::white);
    QBrush BlackPen(Qt::black);
    QBrush RedPen(Qt::red);
    QBrush Pen(QColor(82, 191, 255));

    //设置画笔粗度
    YellowPen.setWidth(4);
    BluePen.setWidth(4);
    GreenPen.setWidth(4);

    //画黄色棋盘线
    painter.setPen(YellowPen);
    painter.drawLine(3 * margin, 3 * margin, 8 * margin, 3 * margin);
    painter.drawLine(3 * margin, 3 * margin, 3 * margin, 8 * margin);
    painter.drawLine(8 * margin, 3 * margin, 8 * margin, 8 * margin);
    painter.drawLine(3 * margin, 8 * margin, 8 * margin, 8 * margin);

    //画蓝色棋盘线
    painter.setPen(BluePen);
    painter.drawLine(4 * margin, 3 * margin, 4 * margin, 8 * margin);
    painter.drawLine(7 * margin, 3 * margin, 7 * margin, 8 * margin);
    painter.drawLine(3 * margin, 4 * margin, 8 * margin, 4 * margin);
    painter.drawLine(3 * margin, 7 * margin, 8 * margin, 7 * margin);

    //画蓝色吃子线
    QRectF left_top(2 * margin, 2 * margin, 2 * margin, 2 * margin);
    painter.drawArc(left_top, 0, 270 * 16);
    QRectF right_top(7 * margin, 2 * margin, 2 * margin, 2 * margin);
    painter.drawArc(right_top, 270 * 16, 270 * 16);
    QRectF left_bottom(2 * margin, 7 * margin, 2 * margin, 2 * margin);
    painter.drawArc(left_bottom, 90 * 16, 270 * 16);
    QRectF right_bottom(7 * margin, 7 * margin, 2 * margin, 2 * margin);
    painter.drawArc(right_bottom, 180 * 16, 270 * 16);

    //画绿色棋盘线
    painter.setPen(GreenPen);
    painter.drawLine(5 * margin, 3 * margin, 5 * margin, 8 * margin);
    painter.drawLine(6 * margin, 3 * margin, 6 * margin, 8 * margin);
    painter.drawLine(3 * margin, 5 * margin, 8 * margin, 5 * margin);
    painter.drawLine(3 * margin, 6 * margin, 8 * margin, 6 * margin);

    //画绿色吃子线
    QRectF Left_top(1 * margin, 1 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Left_top, 0, 270 * 16);
    QRectF Right_top(6 * margin, 1 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Right_top, 270 * 16, 270 * 16);
    QRectF Left_bottom(1 * margin, 6 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Left_bottom, 90 * 16, 270 * 16);
    QRectF Right_bottom(6 * margin, 6 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Right_bottom, 180 * 16, 270 * 16);

    //先获取棋盘
    int R = 0.75 * margin;
    painter.setPen(WhitePen);
    std::vector<std::vector<int>> Board = List[now_step];

    //画棋子
    for(int i = 0; i < 6; ++i) {
        for(int j = 0; j < 6; ++j) {
            if(Board[i][j] == 0) {
                painter.setBrush(BlackPen);
                painter.drawEllipse((j + 3) * margin - 1.0 / 3 * margin, (i + 3) * margin - 1.0 / 3 * margin, R, R);
            } else if(Board[i][j] == 1) {
                painter.setBrush(RedPen);
                painter.drawEllipse((j + 3) * margin - 1.0 / 3 * margin, (i + 3) * margin - 1.0 / 3 * margin, R, R);
            }
        }
    }
}

End_widget::~End_widget()
{
    delete ui;
}
