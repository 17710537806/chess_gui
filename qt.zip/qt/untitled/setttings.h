#ifndef SETTTINGS_H
#define SETTTINGS_H

#include <QWidget>

namespace Ui {
class Setttings;
}

class Setttings : public QWidget
{
    Q_OBJECT

public:
    explicit Setttings(QWidget *parent = nullptr);
    ~Setttings();

private:
    Ui::Setttings *ui;
};

#endif // SETTTINGS_H
