#include "mainwindow.h"
#include "qdatetime.h"
#include "ui_mainwindow.h"

const double ratio = 3.0 / 4.0;

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    //设置窗口图标
    setWindowIcon(QIcon(":/icon.png"));

    //设置窗口标题
    setWindowTitle("苏拉卡尔塔");

    //创建棋盘指针
    board = new Game_board();

    //创建计时器标签
    TimerLabel = new QLabel(this);
    TimerLabel->setFixedSize(200, 60);

    //创建定时器对象
    Timer = new QTimer(this);

    //创建结算窗口
    ew = new End_widget();

    //创建菜单窗口
    mu = new Menu();

    //设置定时器间隔
    Timer->setInterval(0);

    //设置步数时间
    time = 5;

    //最开始没切换过先后手
    is_changed = false;

    //初始化
    init();

    //连接定时器的timeout信号到槽函数
    connect(Timer, &QTimer::timeout, this, &MainWindow::Countdown);

    targetTime = QTime::currentTime().addSecs(time);

    //连接各自的信号
    connect(ui->btn_begin, &QPushButton::clicked, this, &MainWindow::onBtnBeginClicked);
    connect(ui->btn_stop, &QPushButton::clicked, this, &MainWindow::onBtnStopClicked);
    connect(ui->btn_change, &QPushButton::clicked, this, &MainWindow::onBtnChangeClicked);
    connect(ui->btn_retract, &QPushButton::clicked, this, &MainWindow::onBtnRetractClicked);
    connect(ui->btn_defeat, &QPushButton::clicked, this, &MainWindow::onBtnDefeatClicked);
    connect(ui->btn_menu, &QPushButton::clicked, this, &MainWindow::onBtnMenuClicked);

    //设置按键位置
    btn_position();

    //对齐Vector
    TimeVector.push_back(0);
}

void MainWindow::onBtnMenuClicked() {
    //打开菜单窗体
    mu->init();
    mu->show();
}

void MainWindow::onBtnDefeatClicked() {
    //认输则结束比赛
    ew->set_List(board->get_List());
    if(change) {
        ew->get_winner(board->get_nowPlayer(), 0);
    } else {
        ew->get_winner(board->get_nowPlayer() ^ 1, 0);
    }
    ew->set_time(TimeVector);
    ew->show();
    is_end = true;
    Timer->stop();
}

void MainWindow::onBtnRetractClicked() {
    //悔棋
    board->Retract();
    if(TimeVector.size() != 1) TimeVector.pop_back();
    qDebug() << "玩家悔棋";
    update();
}

void MainWindow::onBtnStopClicked() {
    //获取当前时间
    qDebug() << "游戏终止";
    QTime currentTime = QTime::currentTime();

    //计算剩余时间
    remainingSeconds = currentTime.secsTo(targetTime);

    Timer->stop();

    //终止比赛
    is_in_game = false;
}

void MainWindow::init() {
    //初始化
    remainingSeconds = time;
    is_select = false;
    select_x = select_y = -1;
    is_in_game = false;
    is_first = true;
    is_end = false;
    change = false;
    refresh = false;
    TimeVector.clear();
}

void MainWindow::onBtnBeginClicked() {
    //如果游戏已经结束则为新开一盘
    qDebug() << "游戏开始";
    if(is_end) {
        init();
        board->init();
        if(is_changed) board->change_player();
        is_first = false;
        is_in_game = true;
        refresh = true;
        Timer->start();
        update();
        return;
    }

    Timer->start();

    //添加比赛时间
    targetTime = QTime::currentTime().addSecs(remainingSeconds);

    is_first = false;

    //开始比赛
    is_in_game = true;
}

void MainWindow::onBtnChangeClicked() {
    //如果不是最开始或者在比赛中则无效
    if(!((is_first && !is_in_game) || is_end)) {
        return;
    }
    qDebug() << "切换先手";
    change = !change;
    is_changed = !is_changed;
}

void MainWindow::btn_position() {
    //button指针容器
    std::vector<QPushButton*> ButtonVector;

    //设置按键
    ButtonVector.push_back(ui->btn_begin);
    ButtonVector.push_back(ui->btn_stop);
    ButtonVector.push_back(ui->btn_change);
    ButtonVector.push_back(ui->btn_retract);
    ButtonVector.push_back(ui->btn_defeat);
    ButtonVector.push_back(ui->btn_menu);

    //获取当前窗体大小
    int width = this->width(), height = this->height();

    //求出按键数量
    int btn_size = ButtonVector.size();

    //自定义设置留白
    int max_size = fmin(width, height);
    int margin = max_size / 11;

    //根据以上求出按键长度和宽度
    int btn_width = width / 4 - margin;
    int btn_height = (height - margin * (btn_size + 1)) / btn_size;

    //设置横坐标位置
    int x = width * 3 / 4;

    //设置按键大小和位置
    for(int i = 0; i < btn_size; ++i) {
        ButtonVector[i]->setGeometry(x, (i + 1) * margin + i * btn_height, btn_width, btn_height);
    }
}
void MainWindow::Countdown() {
    //获取当前时间
    QTime currentTime = QTime::currentTime();

    //计算剩余时间
    remainingSeconds = currentTime.secsTo(targetTime);

    //如果计时器刷新
    if(refresh) {
        qDebug() << "此步时间:" << time - remainingSeconds;
        TimeVector.push_back(time - remainingSeconds);
        targetTime = QTime::currentTime().addSecs(time);
        refresh = false;
    }

    //计算剩余时间
    remainingSeconds = currentTime.secsTo(targetTime);

    if (remainingSeconds <= 0) {
        // 倒计时结束，停止定时器
        Timer->stop();
        TimerLabel->setText("比赛结束！");
        is_end = true;
        ew->set_List(board->get_List());
        if(change) {
            ew->get_winner(board->get_nowPlayer(), 1);
        } else {
            ew->get_winner(board->get_nowPlayer() ^ 1, 1);
        }
        ew->set_time(TimeVector);
        ew->show();
    } else {
        // 将剩余时间格式化为字符串
        QString countdownString = QString("%1:%2:%3")
                                      .arg(remainingSeconds / 3600, 2, 10, QLatin1Char('0'))
                                      .arg((remainingSeconds / 60) % 60, 2, 10, QLatin1Char('0'))
                                      .arg(remainingSeconds % 60, 2, 10, QLatin1Char('0'));

        // 在标签中显示倒计时
        TimerLabel->setStyleSheet("color: red; font-size: 24px; font-weight: bold;");
        TimerLabel->setText(countdownString);
    }
}

void MainWindow::resizeEvent(QResizeEvent *event) {
    QSize newSize = event->size();
    int newWidth = newSize.width();
    int newHeight = newSize.height();

    // 按照比例调整窗口大小
    int scaledWidth, scaledHeight;
    if (newWidth > newHeight) {
        scaledWidth = newWidth;
        scaledHeight = newWidth * ratio;
    } else {
        scaledWidth = newHeight / ratio;
        scaledHeight = newHeight;
    }

    // 设置新的窗口大小
    resize(scaledWidth, scaledHeight);

    btn_position();

    QWidget::resizeEvent(event);
}

void MainWindow::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);

    //获取窗口长和宽
    int width = this->width(), height = this->height();
    //qDebug() << "width:" << width << "heigh:" << height;

    //求棋盘可以获取最大的大小，并进行留白
    int max_size = fmin(width, height);
    int margin = max_size / 11;

    //设置画笔
    QPainter painter(this);

    //设置画笔颜色
    QPen YellowPen(QColor(255, 242, 0));
    QPen BluePen(QColor(0, 162, 232));
    QPen GreenPen(QColor(22, 116, 50));
    QPen WhitePen(Qt::white);
    QBrush BlackPen(Qt::black);
    QBrush RedPen(Qt::red);
    QBrush Pen(QColor(82, 191, 255));

    //设置画笔粗度
    YellowPen.setWidth(4);
    BluePen.setWidth(4);
    GreenPen.setWidth(4);

    //画黄色棋盘线
    painter.setPen(YellowPen);
    painter.drawLine(3 * margin, 3 * margin, 8 * margin, 3 * margin);
    painter.drawLine(3 * margin, 3 * margin, 3 * margin, 8 * margin);
    painter.drawLine(8 * margin, 3 * margin, 8 * margin, 8 * margin);
    painter.drawLine(3 * margin, 8 * margin, 8 * margin, 8 * margin);

    //画蓝色棋盘线
    painter.setPen(BluePen);
    painter.drawLine(4 * margin, 3 * margin, 4 * margin, 8 * margin);
    painter.drawLine(7 * margin, 3 * margin, 7 * margin, 8 * margin);
    painter.drawLine(3 * margin, 4 * margin, 8 * margin, 4 * margin);
    painter.drawLine(3 * margin, 7 * margin, 8 * margin, 7 * margin);

    //画蓝色吃子线
    QRectF left_top(2 * margin, 2 * margin, 2 * margin, 2 * margin);
    painter.drawArc(left_top, 0, 270 * 16);
    QRectF right_top(7 * margin, 2 * margin, 2 * margin, 2 * margin);
    painter.drawArc(right_top, 270 * 16, 270 * 16);
    QRectF left_bottom(2 * margin, 7 * margin, 2 * margin, 2 * margin);
    painter.drawArc(left_bottom, 90 * 16, 270 * 16);
    QRectF right_bottom(7 * margin, 7 * margin, 2 * margin, 2 * margin);
    painter.drawArc(right_bottom, 180 * 16, 270 * 16);

    //画绿色棋盘线
    painter.setPen(GreenPen);
    painter.drawLine(5 * margin, 3 * margin, 5 * margin, 8 * margin);
    painter.drawLine(6 * margin, 3 * margin, 6 * margin, 8 * margin);
    painter.drawLine(3 * margin, 5 * margin, 8 * margin, 5 * margin);
    painter.drawLine(3 * margin, 6 * margin, 8 * margin, 6 * margin);

    //画绿色吃子线
    QRectF Left_top(1 * margin, 1 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Left_top, 0, 270 * 16);
    QRectF Right_top(6 * margin, 1 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Right_top, 270 * 16, 270 * 16);
    QRectF Left_bottom(1 * margin, 6 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Left_bottom, 90 * 16, 270 * 16);
    QRectF Right_bottom(6 * margin, 6 * margin, 4 * margin, 4 * margin);
    painter.drawArc(Right_bottom, 180 * 16, 270 * 16);

    //先获取棋盘
    int R = 0.75 * margin;
    painter.setPen(WhitePen);
    std::vector<std::vector<int>> Board = board->get_board();

    //如果存在选中则先画出选中的边框
    if(is_select) {
        painter.setBrush(Pen);
        int i = select_x, j = select_y;
        painter.drawEllipse((j + 3) * margin - 1.0 / 3 * margin - 2.2, (i + 3) * margin - 1.0 / 3 * margin - 2.2, R + 5, R + 5);
    }

    //画棋子
    for(int i = 0; i < 6; ++i) {
        for(int j = 0; j < 6; ++j) {
            if(Board[i][j] == 0) {
                painter.setBrush(BlackPen);
                painter.drawEllipse((j + 3) * margin - 1.0 / 3 * margin, (i + 3) * margin - 1.0 / 3 * margin, R, R);
            } else if(Board[i][j] == 1) {
                painter.setBrush(RedPen);
                painter.drawEllipse((j + 3) * margin - 1.0 / 3 * margin, (i + 3) * margin - 1.0 / 3 * margin, R, R);
            }
        }
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event) {
    //如果不在比赛中或者比赛结束则鼠标操作无效
    if(!is_in_game || is_end) return;

    if(change) {
        change = false;
        this->board->change_player();
    }
    //调用基类的鼠标事件处理函数
    QWidget::mousePressEvent(event);

    qDebug() << "当前玩家为" << this->board->get_nowPlayer();
    int mouseX = event->position().x();
    int mouseY = event->position().y();

    int width = this->width(), height = this->height();
    int max_size = fmin(width, height);
    int margin = max_size / 11;
    int R = 0.75 * margin;

    //获取棋盘
    std::vector<std::vector<int>> Board = board->get_board();

    for (int i = 0; i < 6; ++i) {
        for (int j = 0; j < 6; ++j) {
            int circleX = (j + 3) * margin - 1.0 / 3 * margin;
            int circleY = (i + 3) * margin - 1.0 / 3 * margin;

            // 判断点击是否在圆内
            if ((mouseX >= circleX && mouseX <= circleX + R) && (mouseY >= circleY && mouseY <= circleY + R)) {
                // 点击了第 i 行，第 j 列的圆
                qDebug() << "Clicked circle at (" << i << ", " << j << ")";

                //如果已经有选中
                if(is_select) {
                    //如果是之前选中的
                    if(select_x == i && select_y == j) {
                        is_select = false;
                        select_x = select_y = -1;
                    } else {
                        //如果是玩家正常操作要下棋
                        if(board->is_legal(select_x, select_y, i, j)) {
                            //实现玩家操作并取消选中
                            board->play(select_x, select_y, i, j);
                            is_select = false;
                            refresh = true;
                            select_x = select_y = -1;
                            qDebug() << "玩家下棋：从" << select_x << select_y << "到" << i << j;








                        } else {
                            //否则修改选中,需要判断是否是自己的棋子
                            if(Board[i][j] == this->board->get_nowPlayer()) {
                                select_x = i;
                                select_y = j;
                            }
                        }
                    }
                } else {//没有选中的
                    if(Board[i][j] != this->board->get_nowPlayer()) return;
                    is_select = true;
                    select_x = i;
                    select_y = j;
                }

                //重画棋盘
                update();
                return;
            }
        }
    }
}

MainWindow::~MainWindow() {
    delete ui;
}

