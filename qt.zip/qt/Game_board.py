# This Python file uses the following encoding: utf-8
import numpy as np

class Game_board:
    #私有部分

    #棋盘
    _board = np.zeros((6, 6), dtype = np.int32)
    #记录比赛过程的顺序表
    _list = []
    #记录双方子数的数
    _cnt1 = 0
    _cnt2 = 0
    _nowplayer = 0

    #判断是否在棋盘内
    def _is_in_board(self, x, y):
        return x >= 0 and x < 6 and y >= 0 and y < 6

    #判断走子是否合法
    def _is_legal(self, color, x1, y1, x2, y2):
        #如果初始位置和目标位置不在棋盘内则返回false，如果初始值跟当前玩家的子不匹配，返回false
        if not(self._is_in_board(x1, y1)) or not(self._is_in_board(x2, y2)) or self._board[x1][y1] != color:
            return False
        #如果初始点和目标点一致，则返回false
        elif (x1 == x2 and y1 == y2):
            return False
        else:
            #如果是吃子
            if self._board[x2][y2] == color ^ 1:
                #如果不在四个边上，肯定非法吃子
                if not(x1 == 0 or x1 == 5 or y1 == 0 or y1 == 5):
                    return False
                #如果是四个角，则也非法
                elif (x1 == y1 or x1 + y1 == 5) and (x1 == 0 or x1 == 5):
                    return False
                else:
                    #判断四个点方位
                    #如果是二四象限的
                    if(x1 <= 2 and y1 <= 2) or (x1 >= 3 and y1 >= 3):
                        return x1 == y2 and y1 == x2
                    #否则就是一三象限的
                    else:
                        return x1 + y2 == 5 and x2 + y1 == 5
            #否则是正常走步
            else:
                #如果目标点不为空则返回false
                if(self._board[x2][y2] != -1):
                    return False
                #否则判断是否水平和竖直唯一是否绝对值小于1
                return abs(x1 - x2) <= 1 and abs(y1 - y2) <= 1

    #走子
    def _move(self, x1, y1, x2, y2):
        #判断有没有吃子的情况发生
        if self._board[x2][y2] == 0:
            self._cnt1 = self._cnt1 - 1
        elif self._board[x2][y2] == 1:
            self._cnt2 = self._cnt2 - 1
        #移动子并将移动前的位置置空
        self._board[x2][y2] = self._board[x1][y1]
        self._board[x1][y1] = -1

    #公有部分

    #构造函数以及初始化
    def __init__(self):
        for i in range(0, 6):
            for j in  range(0, 6):
                #前两行都为玩家1的棋子
                if i <= 1:
                    self._board[i][j] = 0
                #后两行都为玩家1的棋子
                elif i >= 4:
                    self._board[i][j] = 1
                #其余为空棋盘
                else:
                    self._board[i][j] = -1
        #清空比赛状态
        self._list.clear()
        #初始化棋盘上棋子数分别为12
        self._cnt1 = 12
        self._cnt2 = 12
        #初始化棋盘上最初走子为玩家1
        self._nowplayer = 0

    #进行游戏
    def play(self, x1, y1, x2, y2):
        #如果操作非法
        if not self._is_legal(self._nowplayer, x1, y1, x2, y2):
            return -1
        #执行玩家操作
        self._move(x1, y1, x2, y2)
        #交换回合
        self._nowplayer = self._nowplayer ^ 1
        #将当前棋盘状态存入顺序表
        self._list.append(self._board)
        #如果玩家1的棋子被吃光
        if self._cnt1 == 0:
            return 2
        #如果玩家2的棋子被吃光
        if self._cnt2 == 0:
            return 1
        return 0

    #获取棋盘
    def get_board(self):
        return self._board
