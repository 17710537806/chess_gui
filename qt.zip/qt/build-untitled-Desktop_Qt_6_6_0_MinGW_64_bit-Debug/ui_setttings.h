/********************************************************************************
** Form generated from reading UI file 'setttings.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTTINGS_H
#define UI_SETTTINGS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Setttings
{
public:
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QGroupBox *groupBox_4;
    QHBoxLayout *horizontalLayout_2;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton;
    QRadioButton *radioButton_3;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_3;
    QRadioButton *radioButton_5;
    QRadioButton *radioButton_4;

    void setupUi(QWidget *Setttings)
    {
        if (Setttings->objectName().isEmpty())
            Setttings->setObjectName("Setttings");
        Setttings->resize(400, 300);
        groupBox_2 = new QGroupBox(Setttings);
        groupBox_2->setObjectName("groupBox_2");
        groupBox_2->setGeometry(QRect(10, 10, 381, 281));
        verticalLayout_2 = new QVBoxLayout(groupBox_2);
        verticalLayout_2->setObjectName("verticalLayout_2");
        groupBox_3 = new QGroupBox(groupBox_2);
        groupBox_3->setObjectName("groupBox_3");
        groupBox_3->setMaximumSize(QSize(16777215, 60));
        horizontalLayout = new QHBoxLayout(groupBox_3);
        horizontalLayout->setObjectName("horizontalLayout");
        label = new QLabel(groupBox_3);
        label->setObjectName("label");
        QFont font;
        font.setPointSize(15);
        label->setFont(font);

        horizontalLayout->addWidget(label);

        lineEdit = new QLineEdit(groupBox_3);
        lineEdit->setObjectName("lineEdit");

        horizontalLayout->addWidget(lineEdit);


        verticalLayout_2->addWidget(groupBox_3);

        groupBox_4 = new QGroupBox(groupBox_2);
        groupBox_4->setObjectName("groupBox_4");
        horizontalLayout_2 = new QHBoxLayout(groupBox_4);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        groupBox = new QGroupBox(groupBox_4);
        groupBox->setObjectName("groupBox");
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setObjectName("verticalLayout");
        radioButton_2 = new QRadioButton(groupBox);
        radioButton_2->setObjectName("radioButton_2");
        radioButton_2->setMinimumSize(QSize(0, 30));
        QFont font1;
        font1.setPointSize(20);
        radioButton_2->setFont(font1);

        verticalLayout->addWidget(radioButton_2);

        radioButton = new QRadioButton(groupBox);
        radioButton->setObjectName("radioButton");
        radioButton->setMinimumSize(QSize(0, 30));
        radioButton->setFont(font1);

        verticalLayout->addWidget(radioButton);

        radioButton_3 = new QRadioButton(groupBox);
        radioButton_3->setObjectName("radioButton_3");
        radioButton_3->setMinimumSize(QSize(0, 30));
        radioButton_3->setFont(font1);

        verticalLayout->addWidget(radioButton_3);


        horizontalLayout_2->addWidget(groupBox);

        groupBox_5 = new QGroupBox(groupBox_4);
        groupBox_5->setObjectName("groupBox_5");
        verticalLayout_3 = new QVBoxLayout(groupBox_5);
        verticalLayout_3->setObjectName("verticalLayout_3");
        radioButton_5 = new QRadioButton(groupBox_5);
        radioButton_5->setObjectName("radioButton_5");
        QFont font2;
        font2.setPointSize(25);
        radioButton_5->setFont(font2);

        verticalLayout_3->addWidget(radioButton_5);

        radioButton_4 = new QRadioButton(groupBox_5);
        radioButton_4->setObjectName("radioButton_4");
        radioButton_4->setFont(font2);

        verticalLayout_3->addWidget(radioButton_4);


        horizontalLayout_2->addWidget(groupBox_5);


        verticalLayout_2->addWidget(groupBox_4);


        retranslateUi(Setttings);

        QMetaObject::connectSlotsByName(Setttings);
    } // setupUi

    void retranslateUi(QWidget *Setttings)
    {
        Setttings->setWindowTitle(QCoreApplication::translate("Setttings", "Form", nullptr));
        groupBox_2->setTitle(QString());
        groupBox_3->setTitle(QString());
        label->setText(QCoreApplication::translate("Setttings", "\350\257\267\350\256\276\347\275\256\345\215\225\346\255\245\346\227\266\351\227\264\357\274\232", nullptr));
        groupBox_4->setTitle(QString());
        groupBox->setTitle(QString());
        radioButton_2->setText(QCoreApplication::translate("Setttings", "\344\272\272\344\272\272\345\257\271\346\210\230", nullptr));
        radioButton->setText(QCoreApplication::translate("Setttings", "\344\272\272\346\234\272\345\257\271\346\210\230", nullptr));
        radioButton_3->setText(QCoreApplication::translate("Setttings", "ai\344\272\222\345\215\232\345\274\210", nullptr));
        groupBox_5->setTitle(QString());
        radioButton_5->setText(QCoreApplication::translate("Setttings", "\351\273\221\346\226\271\345\205\210\346\211\213", nullptr));
        radioButton_4->setText(QCoreApplication::translate("Setttings", "\347\272\242\346\226\271\345\205\210\346\211\213", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Setttings: public Ui_Setttings {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTTINGS_H
