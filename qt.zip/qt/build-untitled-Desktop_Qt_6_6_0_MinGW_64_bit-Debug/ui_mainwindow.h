/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *btn_begin;
    QPushButton *btn_stop;
    QPushButton *btn_change;
    QPushButton *btn_retract;
    QPushButton *btn_menu;
    QPushButton *btn_defeat;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        btn_begin = new QPushButton(centralwidget);
        btn_begin->setObjectName("btn_begin");
        btn_begin->setGeometry(QRect(360, 140, 80, 18));
        QFont font;
        font.setPointSize(15);
        btn_begin->setFont(font);
        btn_stop = new QPushButton(centralwidget);
        btn_stop->setObjectName("btn_stop");
        btn_stop->setGeometry(QRect(450, 140, 80, 18));
        QFont font1;
        font1.setPointSize(20);
        btn_stop->setFont(font1);
        btn_change = new QPushButton(centralwidget);
        btn_change->setObjectName("btn_change");
        btn_change->setGeometry(QRect(360, 170, 80, 18));
        btn_change->setFont(font);
        btn_retract = new QPushButton(centralwidget);
        btn_retract->setObjectName("btn_retract");
        btn_retract->setGeometry(QRect(450, 170, 80, 18));
        btn_retract->setFont(font1);
        btn_menu = new QPushButton(centralwidget);
        btn_menu->setObjectName("btn_menu");
        btn_menu->setGeometry(QRect(360, 200, 80, 18));
        btn_menu->setFont(font1);
        btn_defeat = new QPushButton(centralwidget);
        btn_defeat->setObjectName("btn_defeat");
        btn_defeat->setGeometry(QRect(450, 200, 80, 18));
        btn_defeat->setFont(font1);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 17));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        btn_begin->setText(QCoreApplication::translate("MainWindow", "\345\274\200\345\247\213/\347\273\247\347\273\255", nullptr));
        btn_stop->setText(QCoreApplication::translate("MainWindow", "\346\232\202\345\201\234", nullptr));
        btn_change->setText(QCoreApplication::translate("MainWindow", "\345\210\207\346\215\242\345\205\210\345\220\216\346\211\213", nullptr));
        btn_retract->setText(QCoreApplication::translate("MainWindow", "\346\202\224\346\243\213", nullptr));
        btn_menu->setText(QCoreApplication::translate("MainWindow", "\350\217\234\345\215\225", nullptr));
        btn_defeat->setText(QCoreApplication::translate("MainWindow", "\350\256\244\350\276\223", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
