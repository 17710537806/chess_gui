/********************************************************************************
** Form generated from reading UI file 'menu.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENU_H
#define UI_MENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Menu
{
public:
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout;
    QPushButton *btn_new;
    QPushButton *btn_read;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_2;
    QPushButton *btn_set;
    QPushButton *btn_exit;
    QScrollBar *line;
    QLabel *red_label;
    QLabel *black_label;

    void setupUi(QWidget *Menu)
    {
        if (Menu->objectName().isEmpty())
            Menu->setObjectName("Menu");
        Menu->resize(650, 450);
        Menu->setMinimumSize(QSize(650, 450));
        Menu->setMaximumSize(QSize(650, 450));
        groupBox = new QGroupBox(Menu);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(400, 110, 250, 251));
        horizontalLayout = new QHBoxLayout(groupBox);
        horizontalLayout->setObjectName("horizontalLayout");
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName("groupBox_2");
        verticalLayout = new QVBoxLayout(groupBox_2);
        verticalLayout->setObjectName("verticalLayout");
        btn_new = new QPushButton(groupBox_2);
        btn_new->setObjectName("btn_new");
        btn_new->setMinimumSize(QSize(1, 60));
        QFont font;
        font.setPointSize(15);
        btn_new->setFont(font);

        verticalLayout->addWidget(btn_new);

        btn_read = new QPushButton(groupBox_2);
        btn_read->setObjectName("btn_read");
        btn_read->setMinimumSize(QSize(0, 60));
        btn_read->setFont(font);

        verticalLayout->addWidget(btn_read);


        horizontalLayout->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(groupBox);
        groupBox_3->setObjectName("groupBox_3");
        verticalLayout_2 = new QVBoxLayout(groupBox_3);
        verticalLayout_2->setObjectName("verticalLayout_2");
        btn_set = new QPushButton(groupBox_3);
        btn_set->setObjectName("btn_set");
        btn_set->setMinimumSize(QSize(0, 60));
        btn_set->setFont(font);

        verticalLayout_2->addWidget(btn_set);

        btn_exit = new QPushButton(groupBox_3);
        btn_exit->setObjectName("btn_exit");
        btn_exit->setMinimumSize(QSize(0, 60));
        btn_exit->setFont(font);

        verticalLayout_2->addWidget(btn_exit);


        horizontalLayout->addWidget(groupBox_3);

        line = new QScrollBar(Menu);
        line->setObjectName("line");
        line->setGeometry(QRect(30, 400, 580, 20));
        line->setOrientation(Qt::Horizontal);
        red_label = new QLabel(Menu);
        red_label->setObjectName("red_label");
        red_label->setGeometry(QRect(570, 40, 135, 50));
        black_label = new QLabel(Menu);
        black_label->setObjectName("black_label");
        black_label->setGeometry(QRect(440, 40, 273, 50));

        retranslateUi(Menu);

        QMetaObject::connectSlotsByName(Menu);
    } // setupUi

    void retranslateUi(QWidget *Menu)
    {
        Menu->setWindowTitle(QCoreApplication::translate("Menu", "Form", nullptr));
        groupBox->setTitle(QString());
        groupBox_2->setTitle(QString());
        btn_new->setText(QCoreApplication::translate("Menu", "\346\226\260\346\270\270\346\210\217", nullptr));
        btn_read->setText(QCoreApplication::translate("Menu", "\350\257\273\345\217\226\346\243\213\350\260\261", nullptr));
        groupBox_3->setTitle(QString());
        btn_set->setText(QCoreApplication::translate("Menu", "\350\256\276\347\275\256", nullptr));
        btn_exit->setText(QCoreApplication::translate("Menu", "\350\277\224\345\233\236", nullptr));
        red_label->setText(QCoreApplication::translate("Menu", "X 12", nullptr));
        black_label->setText(QCoreApplication::translate("Menu", "X 12", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Menu: public Ui_Menu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENU_H
