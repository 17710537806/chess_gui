/********************************************************************************
** Form generated from reading UI file 'end_widget.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_END_WIDGET_H
#define UI_END_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_End_widget
{
public:
    QScrollBar *get_now_step;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QLabel *winner;
    QLabel *time;
    QPushButton *btn_save;
    QPushButton *btn_exit;

    void setupUi(QWidget *End_widget)
    {
        if (End_widget->objectName().isEmpty())
            End_widget->setObjectName("End_widget");
        End_widget->resize(600, 450);
        End_widget->setMinimumSize(QSize(600, 450));
        End_widget->setMaximumSize(QSize(600, 450));
        get_now_step = new QScrollBar(End_widget);
        get_now_step->setObjectName("get_now_step");
        get_now_step->setGeometry(QRect(40, 380, 331, 21));
        get_now_step->setOrientation(Qt::Horizontal);
        groupBox = new QGroupBox(End_widget);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(410, -10, 191, 461));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setObjectName("verticalLayout");
        winner = new QLabel(groupBox);
        winner->setObjectName("winner");
        winner->setMaximumSize(QSize(16777215, 30));

        verticalLayout->addWidget(winner);

        time = new QLabel(groupBox);
        time->setObjectName("time");
        time->setMaximumSize(QSize(16777215, 30));

        verticalLayout->addWidget(time);

        btn_save = new QPushButton(groupBox);
        btn_save->setObjectName("btn_save");
        btn_save->setMinimumSize(QSize(0, 50));
        QFont font;
        font.setPointSize(18);
        btn_save->setFont(font);

        verticalLayout->addWidget(btn_save);

        btn_exit = new QPushButton(groupBox);
        btn_exit->setObjectName("btn_exit");
        btn_exit->setMinimumSize(QSize(0, 50));
        btn_exit->setFont(font);

        verticalLayout->addWidget(btn_exit);


        retranslateUi(End_widget);

        QMetaObject::connectSlotsByName(End_widget);
    } // setupUi

    void retranslateUi(QWidget *End_widget)
    {
        End_widget->setWindowTitle(QCoreApplication::translate("End_widget", "Form", nullptr));
        groupBox->setTitle(QString());
        winner->setText(QString());
        time->setText(QString());
        btn_save->setText(QCoreApplication::translate("End_widget", "\344\277\235\345\255\230\346\243\213\350\260\261", nullptr));
        btn_exit->setText(QCoreApplication::translate("End_widget", "\350\277\224\345\233\236", nullptr));
    } // retranslateUi

};

namespace Ui {
    class End_widget: public Ui_End_widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_END_WIDGET_H
